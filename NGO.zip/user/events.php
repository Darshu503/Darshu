<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Nature NGO</title>
        <!----------------------css link---------------------------->
        <link rel="stylesheet" href="style.css" />
        <!----------------------font awesome cdn---------------------------->
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        />
        
      </head>
<body>
    <section class="sub-header">
        <nav>
            <a href="index.php"><img src="img/logo.png" alt="logo" /></a>
            <div class="nav-links" id="navLinks">
              <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                <li><a href="index.php">home</a></li>
                <li><a href="about.php">about us</a></li>
                <li><a href="causes.php">causes</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="blog.php">blogs</a></li>
                <li><a href="contact.php">contact us</a></li>
                <li><a href="donate.php">donate us</a></li>
              </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
          </nav>

        <h1>Upcoming Events</h1>
        <h2>Home <span>/</span> Events</h2>
    </section>
    

     <!-- Event Start -->
     <div class="event">
        <div class="container">
            <div class="header-text">
                <p>Upcoming Events</p>
                <h2>Be ready for our upcoming <br> charity events</h2>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="event-item">
                        <img src="img/blog-3.jpeg" alt="Image">
                        <div class="event-content">
                            <div class="event-meta">
                                <p><i class="fa fa-calendar-alt"></i>01-Feb-23</p>
                                <p><i class="far fa-clock"></i>8:00 - 10:00</p>
                                <p><i class="fa fa-map-marker-alt"></i>Halol Near Pavaghad</p>
                            </div>
                            <div class="event-text">
                                <h3>Green Sweep: Join Us for a Forest Cleanup Event.</h3>
                                <p>
                                Join green wave and make a positive impact on the environment by participating in our forest cleanup event. Help us protect our planet and keep our forests clean and healthy.
                                </p>
                                <a class="btn btn-custom" href="contact.php">Join Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="event-item">
                        <img src="img/blog-4.jpeg" alt="Image">
                        <div class="event-content">
                            <div class="event-meta">
                                <p><i class="fa fa-calendar-alt"></i>20-Jan-23</p>
                                <p><i class="far fa-clock"></i>8:00 - 10:00</p>
                                <p><i class="fa fa-map-marker-alt"></i>Gir Forest</p>
                            </div>
                            <div class="event-text">
                                <h3>Growing Together: Join Green Wave in Planting Trees in Gir Forest.</h3>
                                <p>
                                Join Green Wave in planting trees in the Gir Forest, home to the majestic Asiatic lion. Let's work together to create a greener, more sustainable future for our planet and preserve the natural beauty of one of Gujarat's most cherished destinations.
                                </p>
                                <a class="btn btn-custom" href="contact.php">Join Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="event-item">
                        <img src="img/blog-5.jpeg" alt="Image">
                        <div class="event-content">
                            <div class="event-meta">
                                <p><i class="fa fa-calendar-alt"></i>15-Nov-22</p>
                                <p><i class="far fa-clock"></i>8:00 - 10:00</p>
                                <p><i class="fa fa-map-marker-alt"></i>Sardar Sarovar Dam</p>
                            </div>
                            <div class="event-text">
                                <h3>Clean Sweep: Join Green Wave in Clearing Fallen Trees in Sardar Sarovar Dam.</h3>
                                <p>
                                Join Green Wave in clearing fallen trees in the Sardar Sarovar Dam area and help us preserve the beauty of this important landmark. Let's work together to make a positive impact on the environment and promote a cleaner, healthier future for our community.
                                </p>
                                <a class="btn btn-custom" href="contact.php">Join Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="event-item">
                        <img src="img/blog-2.jpg" alt="Image">
                        <div class="event-content">
                            <div class="event-meta">
                                <p><i class="fa fa-calendar-alt"></i>07-Oct-22</p>
                                <p><i class="far fa-clock"></i>8:00 - 10:00</p>
                                <p><i class="fa fa-map-marker-alt"></i>Vishwamitri River</p>
                            </div>
                            <div class="event-text">
                                <h3>Ride the Wave: Join Green Wave in Cleaning the Vishwamitri River in Vadodara.</h3>
                                <p>
                                Join Green Wave in a mission to clean the Vishwamitri River, a vital waterway for Vadodara's ecosystem. Let's work together to make a positive impact on the environment and promote a cleaner, healthier future for our community.
                                </p>
                                <a class="btn btn-custom" href="contact.php">Join Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Event End -->



    <!-----------------------Footer-------------------------->

    <footer class="footer">
        <h1>Green Wave</h1>
        <div class="social">
          <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa fa-envelope"></i></a>
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
        </div>
      
        <ul class="list">
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
        </ul>
        
        <div class="credit"> created by <span>Darshan</span> </div>
      </footer>
   
      <!-- JavaScript link  -->
    <script src="main.js"></script>
</body>
</html>