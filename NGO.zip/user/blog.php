<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Nature NGO</title>
        <!----------------------css link---------------------------->
        <link rel="stylesheet" href="style.css" />
        <!----------------------font awesome cdn---------------------------->
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        />
        
      </head>
<body>
    <section class="sub-header">
        <nav>
            <a href="index.php"><img src="img/logo.png" alt="logo" /></a>
            <div class="nav-links" id="navLinks">
              <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                <li><a href="index.php">home</a></li>
                <li><a href="about.php">about us</a></li>
                <li><a href="causes.php">causes</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="blog.php">blogs</a></li>
                <li><a href="contact.php">contact us</a></li>
                <li><a href="donate.php">donate us</a></li>
              </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
          </nav>

          <h1>Our Blogs</h1>
          <h2>Home <span>/</span> Blogs</h2>
    </section>
    

    <!-----------------blog section---------------------->
    <section class="post">
    <div class="header-text">
        <p>Our Blog</p>
        <h2>Latest news & articles directly <br> from our blog</h2>
    </div>
    
    <div class="post-container">
        <!-- post box 1 -->
        <div class="post-box">
            <img src="img/blog-3.jpeg" alt="" class="post-img">
            <h2 class="category">News</h2>
            <a href="post-page.php" class="post-title">Green Sweep: Join Us for a Forest Cleanup Event.</a>
            <span class="post-date">01 Feb 2023</span>
            <p class="post-decription">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur tempore fugit consequatur cum omnis temporibus excepturi unde odit. Sunt, fugit ipsum. Doloremque harum officiis assumenda in molestias! Ratione, corrupti libero.</p>
            
            <!-- profile -->
            <div class="profile">
                <img src="img/pic-1.png" alt="" class="profile-img">
                <span class="profile-name">Kiran Suthar</span>
            </div>
        </div>
        <!-- post box 2 -->
        <div class="post-box">
            <img src="img/blog-4.jpeg" alt="" class="post-img">
            <h2 class="category">News</h2>
            <a href="post-page.php" class="post-title">Growing Together: Join Green Wave in Planting Trees in Gir Forest.</a>
            <span class="post-date">20 Jan 2023</span>
            <p class="post-decription">Join Green Wave in planting trees in the Gir Forest, home to the majestic Asiatic lion. Let's work together to create a greener, more sustainable future for our planet and preserve the natural beauty of one of Gujarat's most cherished destinations.</p>
            
            <!-- profile -->
            <div class="profile">
                <img src="img/pic-2.png" alt="" class="profile-img">
                <span class="profile-name">Jully Patel</span>
            </div>
        </div>
        <!-- post box 3 -->
        <div class="post-box">
            <img src="img/blog-5.jpeg" alt="" class="post-img">
            <h2 class="category">News</h2>
            <a href="post-page.php" class="post-title">Clean Sweep: Join Green Wave in Clearing Fallen Trees in Sardar Sarovar Dam.</a>
            <span class="post-date">15 Nov 2022</span>
            <p class="post-decription">Join Green Wave in clearing fallen trees in the Sardar Sarovar Dam area and help us preserve the beauty of this important landmark. Let's work together to make a positive impact on the environment and promote a cleaner, healthier future for our community.</p>
            
            <!-- profile -->
            <div class="profile">
                <img src="img/pic-3.png" alt="" class="profile-img">
                <span class="profile-name">Sania Apte</span>
            </div>
        </div>
        <!-- post box 4 -->
        <div class="post-box">
            <img src="img/blog-2.jpg" alt="" class="post-img">
            <h2 class="category">News</h2>
            <a href="post-page.php" class="post-title">Ride the Wave: Join Green Wave in Cleaning the Vishwamitri River in Vadodara.</a>
            <span class="post-date">07 Oct 2022</span>
            <p class="post-decription">Join Green Wave in a mission to clean the Vishwamitri River, a vital waterway for Vadodara's ecosystem. Let's work together to make a positive impact on the environment and promote a cleaner, healthier future for our community.</p>
            
            <!-- profile -->
            <div class="profile">
                <img src="img/pic-4.png" alt="" class="profile-img">
                <span class="profile-name">Kiran Suthar</span>
            </div>
        </div>
        <!-- post box 5 -->
        <div class="post-box">
            <img src="img/couses-1.jpg" alt="" class="post-img">
            <h2 class="category">News</h2>
            <a href="post-page.php" class="post-title">Switching to Solar: Green Wave's Solar Plant Launch Event in Vadodara</a>
            <span class="post-date">21 Aug 2022</span>
            <p class="post-decription">Join Green Wave in celebrating the launch of our new solar power plant and learn how you can make a positive impact on the environment by adopting renewable energy. The event will feature a tour of the solar plant, speeches from experts in the field of sustainable energy, and interactive exhibits that showcase the benefits of solar power. Come see how solar energy can power a brighter, more sustainable future for Vadodara and beyond!</p>
            
            <!-- profile -->
            <div class="profile">
                <img src="img/pic-5.png" alt="" class="profile-img">
                <span class="profile-name">Jully Patel</span>
            </div>
        </div>
        <!-- post box 6 -->
        <div class="post-box">
            <img src="img/blog-6.webp" alt="" class="post-img">
            <h2 class="category">News</h2>
            <a href="post-page.php" class="post-title">Green Village: Join Green Wave in Cleaning Chharodi Village</a>
            <span class="post-date">17 Jun 2022</span>
            <p class="post-decription">Join Green Wave in cleaning Chharodi Village and making a positive impact on the environment. Let's work together to promote a cleaner, healthier future for our community and create a greener, more sustainable village for generations to come.</p>
            
            <!-- profile -->
            <div class="profile">
                <img src="img/pic-6.png" alt="" class="profile-img">
                <span class="profile-name">Sania Apte</span>
            </div>
        </div>
        <!-- post box 7 -->
        <!-- <div class="post-box">
            <img src="img/blog-1.jpg" alt="" class="post-img">
            <h2 class="category">mobile</h2>
            <a href="post-page.php" class="post-title">how to create  ux design with adobe xd</a>
            <span class="post-date">12 Feb 2022</span>
            <p class="post-decription">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur tempore fugit consequatur cum omnis temporibus excepturi unde odit. Sunt, fugit ipsum. Doloremque harum officiis assumenda in molestias! Ratione, corrupti libero.</p> -->
            
            <!-- profile -->
            <!-- <div class="profile">
                <img src="img/pic-2.png" alt="" class="profile-img">
                <span class="profile-name">Kell magel</span>
            </div>
        </div> -->
        <!-- post box 8 -->
        <!-- <div class="post-box">
            <img src="img/blog-2.jpg" alt="" class="post-img">
            <h2 class="category">mobile</h2>
            <a href="post-page.php" class="post-title">how to create  ux design with adobe xd</a>
            <span class="post-date">12 Feb 2022</span>
            <p class="post-decription">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur tempore fugit consequatur cum omnis temporibus excepturi unde odit. Sunt, fugit ipsum. Doloremque harum officiis assumenda in molestias! Ratione, corrupti libero.</p> -->
            
            <!-- profile -->
            <!-- <div class="profile">
                <img src="img/pic-4.png" alt="" class="profile-img">
                <span class="profile-name">jully bella</span>
            </div>
        </div> -->
        <!-- post box 9 -->
        <!-- <div class="post-box">
            <img src="img/blog-4.jpeg" alt="" class="post-img">
            <h2 class="category">mobile</h2>
            <a href="post-page.php" class="post-title">how to create  ux design with adobe xd</a>
            <span class="post-date">12 Feb 2022</span>
            <p class="post-decription">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur tempore fugit consequatur cum omnis temporibus excepturi unde odit. Sunt, fugit ipsum. Doloremque harum officiis assumenda in molestias! Ratione, corrupti libero.</p> -->
            
            <!-- profile -->
            <!-- <div class="profile">
                <img src="img/pic-4.png" alt="" class="profile-img">
                <span class="profile-name">Kell magel</span>
            </div>
        </div> -->
    </div>
</section>
    

    <!-----------------------Footer-------------------------->

    <footer class="footer">
        <h1>Green Wave</h1>
        <div class="social">
          <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa fa-envelope"></i></a>
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
        </div>
      
        <ul class="list">
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
        </ul>
        
        <div class="credit"> created by <span>Darshan</span> </div>
      </footer>

      <!-- JavaScript link -->
    <script src="main.js"></script>
</body>
</html>