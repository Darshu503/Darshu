<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Nature NGO</title>
        <!----------------------css link---------------------------->
        <link rel="stylesheet" href="style.css" />
        <!----------------------font awesome cdn---------------------------->
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        />
        
      </head>
<body>
    <section class="sub-header">
        <nav>
            <a href="index.php"><img src="img/logo.png" alt="logo" /></a>
            <div class="nav-links" id="navLinks">
              <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                <li><a href="index.php">home</a></li>
                <li><a href="about.php">about us</a></li>
                <li><a href="causes.php">causes</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="blog.php">blogs</a></li>
                <li><a href="contact.php">contact us</a></li>
                <li><a href="donate.php">donate us</a></li>
              </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
          </nav>
        
        <h1>About us</h1>
        <h2>Home <span>/</span> About us</h2>
    </section>
    

    <!-----------------about us content---------------------->

    <section class="about-us">

        <div class="row">
            <div class="about-cal">
                <h3>Learn About Us</h2>
                <h1>Worldwide non-profit charity organization</h1>
                <p>At Green Wave, we believe that small actions can lead to big changes. Whether it's reducing your carbon footprint, advocating for environmental policies, or simply spreading awareness about important issues, every individual has the power to make a difference.</p>
            </div>
            <div class="about-cal">
                <img src="img/about.jpg" alt="about">
            </div>
        </div>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-users"></i>
                <h3>1000+</h3>
                <p>volunteers</p>
            </div>
        
            <div class="box">
                <i class="fas fa-tree"></i>
                <h3>1300+</h3>
                <p>trees planted</p>
            </div>
        
            <div class="box">
                <i class="fas fa-paw"></i>
                <h3>450+</h3>
                <p>animals saved</p>
            </div>
        
            <div class="box">
                <i class="fas fa-donate"></i>
                <h3>850+</h3>
                <p>donators</p>
            </div>
        </div>

    </section>
    
    <section class="team">
        <div class="center">
            <h1 class="heading">Our Team</h1>
        </div>

        <div class="team-content">
            <div class="box">
                <img src="img/pic-3.png" alt="pic1">
                <h3>Darshan Datrange</h3>
                <h5>Founder</h5>
                <div class="icons">
                    <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>

            <div class="box">
                <img src="img/pic-2.png" alt="pic1">
                <h3>Akashara Patel</h3>
                <h5>Co-Founder</h5>
                <div class="icons">
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>

            <div class="box">
                <img src="img/pic-1.png" alt="pic1">
                <h3>Aditya Rajput</h3>
                <h5>Manager</h5>
                <div class="icons">
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
            
            <div class="box">
                <img src="img/pic-4.png" alt="pic1">
                <h3>Sitangi Shah</h3>
                <h5>Asistan Manager</h5>
                <div class="icons">
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>

            <div class="box">
                <img src="img/pic-5.png" alt="pic1">
                <h3>Manan Jadav</h3>
                <h5>Organizer</h5>
                <div class="icons">
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>

            <div class="box">
                <img src="img/pic-6.png" alt="pic1">
                <h3>Divya Soni</h3>
                <h5>Asistan Organizer</h5>
                <div class="icons">
                    <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>
        </div>
        <a href="volunteer.php" class="btn team-btn">Become a Volnnteer</a>
    </section>



    <!-----------------------Footer-------------------------->

    <footer class="footer">
        <h1>Green Wave</h1>
        <div class="social">
          <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa fa-envelope"></i></a>
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
        </div>
      
        <ul class="list">
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
        </ul>
        
        <div class="credit"> created by <span>Darshan</span> </div>
      </footer>
   
    </script> 
    <script src="main.js"></script>
</body>
</html>