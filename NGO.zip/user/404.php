<!DOCTYPE html>
<html>
<head>
	<title>404 Error Page</title>
    <link rel="stylesheet" href="style.css">

	<style>
		.erbody {
            background-color: #f1f1f1;
            text-align: center;
            padding-top: 100px;
        }
        .error{
            margin-top: 100px;
        }
        .error h1 {
            font-size: 100px;
            margin-bottom: 0;
            color: #333333;
        }
        .error p {
            font-size: 20px;
            margin-top: 20px;
            color: #666666;
        }
        .error a {
            background: lightgreen;
            color: #fff;
            padding: 7px 15px;
            border-radius: 10px;
            margin: 15px 0px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .error a:hover {
            box-shadow: 0 5px 7px 0  rgba(0,0,0,.2);
        }
		
	</style>
</head>
<body class="erbody">
    <div class="error">
	    <h1>404</h1>
	    <p>The page you requested could not be found.</p>
	    <p>Please go back to the <a href="../user/index.php">Back</a></p>
    </div>
</body>
</html>
