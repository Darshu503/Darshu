<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Nature NGO</title>
    <!----------------------css link---------------------------->
    <link rel="stylesheet" href="style.css" />
    <!----------------------font awesome cdn---------------------------->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"/>
  </head>
  <body>

    <!-- -----------------nevigation section start-------------------->
    <header class="header">
      <nav>
        <a href="index.php"><img src="img/logo.png" alt=""></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
          </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
      <div class="text-box">
        <h1>save earth,save life</h1>
        <p>
          We can save the earth for future generations in various ways by
          adopting a sensible changes.
        </p>
        <a href="about.php" class="home-btn">Know More</a>
      </div>
    </header>
    <!-- -----------------navigation section start-------------------->
    <main>
      <!-- -----------------about us section start-------------------->
    <section class="about" id="about">
        <h1 class="heading">About Us</h1>

        <div class="row">
            <div class="image">
                <img src="img/about-1.jpeg" alt="about us image" />
            </div>

            <div class="content">
                <h3>Together we can save the planet</h3>
                <p>Our mission is to aware people about nature, and we achieve this through hardwork.</p>
                <p>Founded in 2016, we have been working tirelessly to planting, recycling, water saving. Our team is made up of passionate environmentalists who are committed to making a positive impact on the world.</p>
                <p>At Green Wave, we believe that small actions can lead to big changes. Whether it's reducing your carbon footprint, advocating for environmental policies, or simply spreading awareness about important issues, every individual has the power to make a difference.</p>
                <p>Join us in our efforts to create a more sustainable world. Together, we can build a brighter future for ourselves and for generations to come.</p>
                <a href="about.php" class="btn">read more</a>
            </div>
        </div>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-users"></i>
                <h3>1000+</h3>
                <p>volunteers</p>
            </div>
        
            <div class="box">
                <i class="fas fa-tree"></i>
                <h3>1300+</h3>
                <p>trees planted</p>
            </div>
        
            <div class="box">
                <i class="fas fa-paw"></i>
                <h3>450+</h3>
                <p>animals saved</p>
            </div>
        
            <div class="box">
                <i class="fas fa-donate"></i>
                <h3>850+</h3>
                <p>donators</p>
            </div>
        
        </div>
    </section>
      <!-- -----------------about us section end-------------------->

      <!-- -----------------servises section start------------------ -->
    <section class="services">
        <div class="container">
            <h1 class="heading">What We Do?</h1>

            <div class="row">
                <div class="service">
                <i class="fas fa-seedling"></i>
                <h2>planting</h2>
                <p>Planting Trees.</p>
            </div>
            <div class="service">
                <i class="fas fa-recycle"></i>
                <h2>recycle</h2>
                <p>Recycling waste.</p>
            </div>
            <div class="service">
                <i class="fas fa-hand-holding-water"></i>
                <h2>water saving</h2>
                <p>Cleaning Water.</p>
            </div>
            <div class="service">
                <i class="fas fa-tree"></i>
                <h2>Tree Saving</h2>
                <p>Saving Forests.</p>
            </div>
            <div class="service">
                <i class="fas fa-paw"></i>
                <h2>Animals Saving</h2>
                <p>Saving animals.</p>
            </div>
            <div class="service">
                <i class="fas fa-solar-panel"></i>
                <h2>Solar Panel</h2>
                <p>Planting solar plants.</p>
            </div>
        </div>
      </section>
    <!-- -----------------servises section end------------------ -->

    <!-- -----------------gallary section start------------------ -->
      <section class="projects">
        <h1 class="heading">Our Gallery</h1>

        <div class="container">
          <div class="img-container">
            <div class="image"><img src="img/blog-3.jpeg" alt=""></div>
            <div class="image"><img src="img/blog-2.jpg" alt=""></div>
            <div class="image"><img src="img/gallary-1.jpg" alt=""></div>
            <div class="image"><img src="img/blog-4.jpeg" alt=""></div>
            <div class="image"><img src="img/blog-5.jpeg" alt=""></div>
            <div class="image"><img src="img/blog-6.webp" alt=""></div>
          </div>

         <div class="popup-image">
            <span>&times;</span>
            <img src="img/img10.jpg" alt="">
         </div>
          
        </div>
      </section>
    <!-- -----------------gallary section end------------------ -->
    <!-- -----------------couses section start------------------ -->
    <section class="couses">

      <div class="container">
          <div class="header-text">
              <p>Popular Causes</p>
              <h2>Let's know about charity causes <br> around the world</h2>
          </div>
        <div class="row">

          <div class="content">
            <div class="card">
              <img src="img/couses-1.jpg" alt="blog-1">
              <h3>Planting solar plant near village.</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla assumenda dolorum incidunt architecto nobis inventore, culpa adipisci eos pariatur voluptas.</p>
              <div class="fand">
                <span class="raised">Raised:$2200</span>
                <span class="goal">Goal:$6000</span>
              </div>
                <div class="btn-link">
                <a href="#" class="btn">read more</a>
                <a href="donate.php" class="btn">Donate Now</a>
              </div>
            </div>
            <div class="card">
              <img src="img/blog-2.jpg" alt="blog-1">
              <h3>Cleaning distric river.</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla assumenda dolorum incidunt architecto nobis inventore, culpa adipisci eos pariatur voluptas.</p>
              <div class="fand">
                <span class="raised">Raised:$1500</span>
                <span class="goal">Goal:$3000</span>
              </div>
                <div class="btn-link">
                <a href="#" class="btn">read more</a>
                <a href="donate.php" class="btn">Donate Now</a>
              </div>
            </div>
            <div class="card">
              <img src="img/blog-4.jpeg" alt="blog-1">
              <h3>Planting trees in forest.</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla assumenda dolorum incidunt architecto nobis inventore, culpa adipisci eos pariatur voluptas.</p>
              <div class="fand">
                <span class="raised">Raised:$5500</span>
                <span class="goal">Goal:$10000</span>
              </div>
                <div class="btn-link">
                <a href="#" class="btn">read more</a>
                <a href="donate.php" class="btn">Donate Now</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- -----------------couses section end------------------ -->
    <!-- -----------------testimonials section start------------------ -->
    <section class="testimonials">
      <h1>What Our Client Says</h1>

      <div class="row">
          <div class="testimonial-col">
              <img src="img/pic-1.png" alt="user-1">
              <div>
                  <p>"I'm proud to support Green Wave and their commitment to environmental conservation and sustainability. Their work is inspiring and makes a meaningful impact in protecting our planet."</h3>
                  <h3>Sourav Mistry</h3>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star-o"></i>
              </div>
          </div>
          <div class="testimonial-col">
              <img src="img/pic-3.png" alt="user-2">
              <div>
                  <p>"I'm consistently impressed by Green Wave's dedication to environmental conservation and sustainability. Their work is truly inspiring and impactful. I'm proud to be a part of this organization and support their efforts to build a more sustainable future."</p>
                  <h3>Bargav Patel</h3>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star-half-o"></i>
              </div>
          </div>
          <div class="testimonial-col">
              <img src="img/pic-6.png" alt="user-2">
              <div>
                  <p>"Green Wave is doing impressive work to combat climate change and protect our planet. Their commitment to promoting renewable energy, reducing waste, and advocating for policy change is truly inspiring. The passion and dedication of their staff and volunteers is clear, and I am grateful to support their important work for a more sustainable future."</p>

                  <h3>Shakshi Parmar</h3>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star-half-o"></i>
              </div>
          </div>
      </div>
  </section>
  
  
    <!-- -----------------testimonials section end------------------ -->
    <!-- -----------------paralux section end------------------ -->

    <section class="paralux">
      <div class="overlay">
        <div class="container">
          <h2>If you want to <span> contect us</span>, click below</h2>
          <p>"Your contribution can make a lasting impact on our planet."</p>
          <a href="contact.php" class="btn">Contact Us</a>
          <a href="donate.php" class="btn">Donate Us</a>
        </div>
      </div>
    </section>
    <!-- -----------------paralux section end------------------ -->
    <!-- -----------------blog section end------------------ -->
    <section class="blogs">
      <h1 class="heading">Our Blogs</h1>

      <div class="container">
        <div class="row">

          <div class="content">
            <div class="card">
              <img src="img/blog-1.jpg" alt="blog-1">
              <h3>Saving Dog from road accident</h3>
              <p>When a small injured dog was found, green wave quickly responded, providing medical care and a loving home. Join us in our mission to make a difference in the lives of animals in need.</p>
              <a href="blog.php" class="btn">read more</a>
            </div>
            <div class="card">
              <img src="img/blog-2.jpg" alt="blog-1">
              <h3>Cleaning river</h3>
              <p>Green wave took action to clean up a local river, making it safe for wildlife and the community. Join us in preserving our planet for future generations.</p>
              <a href="blog.php" class="btn">read more</a>
            </div>
            <div class="card">
              <img src="img/blog-4.jpeg" alt="blog-1">
              <h3>Planting trees in forest</h3>
              <p>Green wave planted thousands of trees to restore a damaged forest. Join us in protecting and preserving our planet's forests for a more sustainable future.</p>
              <a href="blog.php" class="btn">read more</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- -----------------blog section end------------------ -->
    <!-- -----------------logo section start------------------ -->
    <section class="logo-container">
      <h1 class="heading">Donators</h1>
      <div class="logo-slider">
         <div class="wrapper">
            <div class="slide"><img src="img/client-logo-1.png" alt=""></div>
            <div class="slide"><img src="img/client-logo-2.png" alt=""></div>
            <div class="slide"><img src="img/client-logo-3.png" alt=""></div>
            <div class="slide"><img src="img/client-logo-4.png" alt=""></div>
            <div class="slide"><img src="img/client-logo-5.png" alt=""></div>
            <div class="slide"><img src="img/client-logo-6.png" alt=""></div>
         </div>
      </div>
   </section>
    <!-- -----------------logo section end------------------ -->
  </main>

<!-- footer section starts  -->

<footer class="footer">
  <h1>Green Wave</h1>
  <div class="social">
    <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
    <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
    <a href="#"><i class="fa-brands fa-twitter"></i></a>
    <a href="#"><i class="fa fa-envelope"></i></a>
    <a href="https://www.facebook.com/darshan.datrnge/"><i class="fa-brands fa-facebook"></i></a>
  </div>

  <ul class="list">
    <li><a href="index.php">home</a></li>
    <li><a href="about.php">about us</a></li>
    <li><a href="causes.php">causes</a></li>
    <li><a href="events.php">Events</a></li>
    <li><a href="blog.php">blogs</a></li>
    <li><a href="contact.php">contact us</a></li>
    <li><a href="donate.php">donate us</a></li>
  </ul>
  
  <div class="credit"> created by <span>Darshan</span> </div>
</footer>


<!-- footer section ends -->

    <!-- -------------JavaScript---------------- -->
    <script src="main.js"></script>
    
  </body>
</html>
