<?php

session_start();

if(isset($_POST['donate'])){

  $name = $_POST['name'];
  $email = $_POST['email'];
  $msg = $_POST['msg'];
  $amt = $_POST['amt'];

    $conn = mysqli_connect('localhost','root','','admin');

    $insert = "INSERT INTO donation_mst(dname, email, message, amt) VALUES('$name','$email','$msg','$amt')";
    $res = mysqli_query($conn, $insert);

    if ($res) {
      ?>
      <script>alert("Thank You For Donation");</script>
      <?php
    }
    else {
      ?>
      <script>alert("Do Not Donate Sucessfully");</script>
      <?php
    }

};
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Nature NGO</title>
        <!----------------------css link---------------------------->
        <link rel="stylesheet" href="style.css" />
        <!----------------------font awesome cdn---------------------------->
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        />
        
      </head>
<body class="donate">
    <section class="sub-header">
        <nav>
            <a href="index.php"><img src="img/logo.png" alt="logo" /></a>
            <div class="nav-links" id="navLinks">
              <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                <li><a href="index.php">home</a></li>
                <li><a href="about.php">about us</a></li>
                <li><a href="causes.php">causes</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="blog.php">blogs</a></li>
                <li><a href="contact.php">contact us</a></li>
                <li><a href="donate.php">donate us</a></li>
              </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
          </nav>
        
        <h1>Donate Now</h1>
        <h2>Home <span>/</span> Donate</h2>
    </section>
    

    <!-- Donate Start -->
    

    <section class="donate-container">
        
        
        <div class="donate-form">
            <form action="donate.php" method="post">
                <h1>Donation Form</h1>
                <h3>Contact information</h3>
                <label for="name">Doner Name*</label><br>
                <input class="box1" type="text" name="name" id="name" placeholder="Enter Name" required><br>
                <label for="email">Email*</label><br>
                <input class="box1" type="email" name="email" id="email" placeholder="Enter Email" required><br>
                <label for="message">Message</label><br>
                <textarea class="box1" name="msg" id="message" cols="30" rows="3" placeholder="Enter Message (optional)"></textarea><br>
                <label for="amount">Amount*</label><br>
                <input class="box1" type="number" name="amt" id="amount" placeholder="Enter Amount" required><br><hr>
                
                <h3>Card information</h3>
                <label for="card_type">Card Type*</label><br>
                <select class="box1" name="card_type" id="card_type" required>
                    <option value=" ---- select a card type">---- select a card type </option>
                     <option value="visa">visa</option>
                     <option value="rupay">rupay</option>
                     <option value="master">master</option>
                </select><br>
                <label for="cardno">Card Number*</label><br>
                <input class="box1" type="number" name="cardno" id="cardno" placeholder="1234 1234 1234" required><br>
                <div class="div1">
                    <label for="cardm">Card Expiry Month*</label><br>
                    <input class="box2" type="date" name="month" id="month" placeholder="MM" required><br>
                </div>
                <div class="div1">
                    <label for="cardcvc">Card CVC*</label><br>
                    <input class="box2" type="number" name="cvc" id="cvc" placeholder="cvc" required><br>
                </div>
                
                <input class="btn1" name="donate" type="submit" value="Donate Now">
                <input class="btn1" type="reset" value="Reset">

            </form>
        </div>
    </section>
    <!-- Donate End -->



    <!-----------------------Footer-------------------------->

    <footer class="footer">
        <h1>Green Wave</h1>
        <div class="social">
          <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa fa-envelope"></i></a>
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
        </div>
      
        <ul class="list">
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
        </ul>
        
        <div class="credit"> created by <span>Darshan</span> </div>
      </footer>
    
    <!-- java script -->
    <script src="main.js"></script>
</body>
</html>