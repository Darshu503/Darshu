<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Nature NGO</title>
        <!----------------------css link---------------------------->
        <link rel="stylesheet" href="style.css" />
        <!----------------------font awesome cdn---------------------------->
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        />
        
      </head>
<body>
    <section class="sub-header">
      <nav>
        <a href="index.php"><img src="img/logo.png" alt="logo" /></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
          </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
        <h1>Causes</h1>
        <h2>Home <span>/</span> Causes</h2>
    </section>
    

     <!-- -----------------servises section start------------------ -->
    <section class="services">
        <div class="container">
          <div class="header-text">
            <p>What We Do?</p>
            <h2>We believe that we can save <br> more lifes with you</h2>
          </div>

          <div class="row">
                <div class="service">
                <i class="fas fa-seedling"></i>
                <h2>planting</h2>
                <p>Planting Trees.</p>
            </div>
            <div class="service">
                <i class="fas fa-recycle"></i>
                <h2>recycle</h2>
                <p>Recycling waste.</p>
            </div>
            <div class="service">
                <i class="fas fa-hand-holding-water"></i>
                <h2>water saving</h2>
                <p>Cleaning Water.</p>
            </div>
            <div class="service">
                <i class="fas fa-tree"></i>
                <h2>Tree Saving</h2>
                <p>Saving Forests.</p>
            </div>
            <div class="service">
                <i class="fas fa-paw"></i>
                <h2>Animals Saving</h2>
                <p>Saving animals.</p>
            </div>
            <div class="service">
                <i class="fas fa-solar-panel"></i>
                <h2>Solar Panel</h2>
                <p>Planting solar plants.</p>
            </div>
        </div>
      </section>
    <!-- -----------------servises section end------------------ -->
    
    <!-- -----------------couses section start------------------ -->
    <section class="couses">

        <div class="container">
            <div class="header-text">
                <p>Popular Causes</p>
                <h2>Let's know about charity causes <br> around the world</h2>
            </div>
          <div class="row">
  
            <div class="content">
              <div class="card">
                <img src="img/couses-1.jpg" alt="blog-1">
                <h3>Planting solar plant near village.</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla assumenda dolorum incidunt architecto nobis inventore, culpa adipisci eos pariatur voluptas.</p>
                <div class="fand">
                  <span class="raised">Raised:$2200</span>
                  <span class="goal">Goal:$6000</span>
                </div>
                  <div class="btn-link">
                  <a href="#" class="btn">read more</a>
                  <a href="donate.php" class="btn">Donate Now</a>
                </div>
              </div>
              <div class="card">
                <img src="img/blog-2.jpg" alt="blog-1">
                <h3>Cleaning distric river.</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla assumenda dolorum incidunt architecto nobis inventore, culpa adipisci eos pariatur voluptas.</p>
                <div class="fand">
                  <span class="raised">Raised:$1500</span>
                  <span class="goal">Goal:$3000</span>
                </div>
                  <div class="btn-link">
                  <a href="#" class="btn">read more</a>
                  <a href="donate.php" class="btn">Donate Now</a>
                </div>
              </div>
              <div class="card">
                <img src="img/blog-4.jpeg" alt="blog-1">
                <h3>Planting trees in forest.</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla assumenda dolorum incidunt architecto nobis inventore, culpa adipisci eos pariatur voluptas.</p>
                <div class="fand">
                  <span class="raised">Raised:$5500</span>
                  <span class="goal">Goal:$10000</span>
                </div>
                  <div class="btn-link">
                  <a href="#" class="btn">read more</a>
                  <a href="donate.php" class="btn">Donate Now</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- -----------------couses section end------------------ -->



    <!-----------------------Footer-------------------------->

    <footer class="footer">
        <h1>Green Wave</h1>
        <div class="social">
          <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa fa-envelope"></i></a>
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
        </div>
      
        <ul class="list">
          <li><a href="index.php">home</a></li>
                <li><a href="about.php">about us</a></li>
                <li><a href="causes.php">causes</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="blog.php">blogs</a></li>
                <li><a href="contact.php">contact us</a></li>
                <li><a href="donate.php">donate us</a></li>
        </ul>
        
        <div class="credit"> created by <span>Darshan</span> </div>
      </footer>
    <!-------------JavaScript link----------------->
    
    <script src="main.js"></script>
</body>
</html>