

<?php

session_start();

if(isset($_POST['request'])){

  $name = $_POST['name'];
  $email = $_POST['email'];
  $moblie = $_POST['moblie'];
  $bod = $_POST['bod'];
  $gender = $_POST['gender'];
  $address = $_POST['address'];

    $conn = mysqli_connect('localhost','root','','admin');

    $insert = "INSERT INTO volunteer_mst(vname, email, mobile, bod, gender, address) VALUES('$name','$email','$moblie','$bod','$gender','$address')";
    $res = mysqli_query($conn, $insert);

   if ($res) {
      ?>
      <script>alert("Request Send Sucessfully");</script>
      <?php
    }
    else {
      ?>
      <script>alert("Request Not Send Sucessfully");</script>
      <?php
    }

};
?>




<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Nature NGO</title>
        <!----------------------css link---------------------------->
        <link rel="stylesheet" href="style.css" />
        <!----------------------font awesome cdn---------------------------->
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        />
        
      </head>
<body>
    <section class="sub-header">
        <nav>
            <a href="index.php"><img src="img/logo.png" alt="logo" /></a>
            <div class="nav-links" id="navLinks">
              <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                <li><a href="index.php">home</a></li>
                <li><a href="about.php">about us</a></li>
                <li><a href="causes.php">causes</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="blog.php">blogs</a></li>
                <li><a href="contact.php">contact us</a></li>
                <li><a href="donate.php">donate us</a></li>
              </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
          </nav>
        
        <h1>Volunteer</h1>
        <h2>Home <span>/</span> Volunteer</h2>
    </section>
    
    <div class="form-container">
      <div class="form-content">
        <div class="title">Volunteer Form</div>
        <div class="content">

        <div class="contact-cal">

                <form action="volunteer.php" method="POST">
                    <input type="text" name="name" placeholder="Enter Your Name" required>
                    <input type="email" name="email" placeholder="Enter Your Email Address" required>
                    <input type="number" name="moblie" placeholder="Enter Your Phone Number" required>
                    <input type="date" name="bod" id="" required>
                    <select id="gender" name="gender" required>
                      <option value="">Select your gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                    <textarea rows="8" name="address" placeholder="Enter Your Address" required></textarea>
                    <button type="submit" name="request" class="btn">Send Request</button>
                </form>
            </div>
        </div>
      </div>
    </div>

  
    <!-----------------------Footer-------------------------->

    <footer class="footer">
        <h1>Green Wave</h1>
        <div class="social">
          <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa fa-envelope"></i></a>
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
        </div>
      
        <ul class="list">
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
        </ul>
        
        <div class="credit"> created by <span>Darshan</span> </div>
      </footer>
   
    </script> 
    <script src="main.js"></script>
</body>
</html>