<?php

session_start();

if(isset($_POST['send'])){

  $name = $_POST['name'];
  $email = $_POST['email'];
  $sub = $_POST['sub'];
  $msg = $_POST['msg'];

    $conn = mysqli_connect('localhost','root','','admin');

    $insert = "INSERT INTO contact_mst(cname, email, subject, message) VALUES('$name','$email','$sub','$msg')";
    $res = mysqli_query($conn, $insert);

   if ($res) {
      ?>
      <script>alert("Send Sucessfully");</script>
      <?php
    }
    else {
      ?>
      <script>alert("Do Not Send Sucessfully");</script>
      <?php
    }

};
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Nature NGO</title>
        <!----------------------css link---------------------------->
        <link rel="stylesheet" href="style.css" />
        <!----------------------font awesome cdn---------------------------->
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        />
        
      </head>
<body>
    <section class="sub-header">
        <nav>
            <a href="index.php"><img src="img/logo.png" alt="logo" /></a>
            <div class="nav-links" id="navLinks">
              <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                <li><a href="index.php">home</a></li>
                <li><a href="about.php">about us</a></li>
                <li><a href="causes.php">causes</a></li>
                <li><a href="events.php">Events</a></li>
                <li><a href="blog.php">blogs</a></li>
                <li><a href="contact.php">contact us</a></li>
                <li><a href="donate.php">donate us</a></li>
              </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
          </nav>
        
        <h1>Contact us</h1>
        <h2>Home <span>/</span> Contact us</h2>
    </section>
    

    <!-----------------contact us---------------------->

    

    <section class="location">

        <div class="header-text">
            <p>Get In Touch</p>
            <h2>Contact us for any query</h2>
        </div>

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.6514307449406!2d72.94928251488187!3d22.554726585191982!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e4e8166edfeeb%3A0x4318eb633abe427!2sAnand%20Institute%20of%20Management%20and%20Information%20Science%20(AIMIS)!5e0!3m2!1sen!2sin!4v1679507817305!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </section>

    <section class="contact-us">

        <div class="row">
            <div class="contact-cal">
                <div>
                    <i class="fa fa-home"></i>
                    <span>
                        <h5>ABC building, XYZ Road</h5>
                        <p>Vadodara, Gujarat, India</p>
                    </span>
                </div>
                <div>
                    <i class="fa fa-phone"></i>
                    <span>
                        <h5>+91 8905112286</h5>
                        <p>Call us 24*7</p>
                    </span>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <span>
                        <h5>greenwave@gmail.com</h5>
                        <p>Email us to Your Query</p>
                    </span>
                </div>
            </div>
            <div class="contact-cal">

                <form action="contact.php" method="post">
                    <input type="text" name="name" placeholder="Enter Your Name" required>
                    <input type="email" name="email" placeholder="Enter Your Email Address" required>
                    <input type="text" name="sub" placeholder="Enter Your Subject" required>
                    <textarea rows="8" name="msg" placeholder="Message" required></textarea>
                    <button type="submit" name="send" class="btn">Send Massage</button>
                </form>
            </div>
        </div>
    </section>

    <!-----------------------Footer-------------------------->

    <footer class="footer">
        <h1>Green Wave</h1>
        <div class="social">
          <a href="https://www.instagram.com/darshan_6884/?next=%2F"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://wa.me/+918905112286"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa fa-envelope"></i></a>
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
        </div>
      
        <ul class="list">
            <li><a href="index.php">home</a></li>
            <li><a href="about.php">about us</a></li>
            <li><a href="causes.php">causes</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="blog.php">blogs</a></li>
            <li><a href="contact.php">contact us</a></li>
            <li><a href="donate.php">donate us</a></li>
        </ul>
        
        <div class="credit"> created by <span>Darshan</span> </div>
      </footer>
    <!-------------JavaScript for Toggle Menu----------------->
    <script src="main.js"></script>
</body>
</html>